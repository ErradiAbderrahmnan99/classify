<?php
// This file was auto-generated from sdk-root/src/data/bcm-data-exports/2023-11-26/paginators-1.json
return [ 'pagination' => [ 'ListExecutions' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Executions', ], 'ListExports' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Exports', ], 'ListTables' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Tables', ], ],];
