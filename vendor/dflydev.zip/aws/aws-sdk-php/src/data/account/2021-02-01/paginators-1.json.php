<?php
// This file was auto-generated from sdk-root/src/data/account/2021-02-01/paginators-1.json
return [ 'pagination' => [ 'ListRegions' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Regions', ], ],];
