# Laravel wizard installer package

![Tests](https://img.shields.io/github/actions/workflow/status/dacoto/laravel-wizard-installer/ci.yml?labelColor=444D56&label=Tests)
![GitHub](https://img.shields.io/github/license/dacoto/laravel-wizard-installer?labelColor=444D56&label=License)
![GitHub release (latest by date)](https://img.shields.io/github/v/release/dacoto/laravel-wizard-installer?labelColor=444D56&label=Release)


## Installation

```sh
composer require dacoto/laravel-wizard-installer
```

Code style will be automatically fixed by php-cs-fixer.
